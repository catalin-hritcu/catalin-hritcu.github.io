import Test.HUnit

f :: Int -> Int
f n = g 0 n
  where g a b
          | a==b       = a
          | c*c > n    = g a (c-1)
          | otherwise  = g c b
          where c = (a+b+1) `div` 2

main = runTestTT $ TestList [
    TestCase $ assertEqual "test0"  (f 0)  0
  , TestCase $ assertEqual "test2"  (f 1)  1
{-  , TestCase $ assertEqual "test42" (f 42) 6-}
  ]
