import Test.HUnit

f :: Int -> Int
f 0 = 0
f 1 = 1
f x = 6

main = runTestTT $ TestList [
    TestCase $ assertEqual "test0"  (f 0)  0
  , TestCase $ assertEqual "test2"  (f 1)  1
  , TestCase $ assertEqual "test42" (f 42) 6
  ]
