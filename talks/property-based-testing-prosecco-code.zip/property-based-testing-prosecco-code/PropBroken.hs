import Test.QuickCheck

f :: Int -> Int
f 0 = 0
f 1 = 1
f x = 6

prop_int_sqrt x =
  x >=0  ==>  (f x * f x <= x  &&  (f x + 1) * (f x + 1) > x)

prop_int_sqrt_small =
  forAllShrink (choose (0, 10000)) shrink prop_int_sqrt
