import Test.QuickCheck

f :: Int -> Int
f n = g 0 n
  where g a b
          | a==b       = a
          | c*c > n    = g a (c-1)
          | otherwise  = g c b
          where c = (a+b+1) `div` 2

prop_int_sqrt x =
  x >= 0  ==>  (f x * f x <= x  &&  (f x + 1) * (f x + 1) > x)

prop_int_sqrt_small =
  forAllShrink (choose (0, 10000)) shrink prop_int_sqrt

main =
  quickCheckWith (stdArgs {maxSuccess = 1000}) prop_int_sqrt_small