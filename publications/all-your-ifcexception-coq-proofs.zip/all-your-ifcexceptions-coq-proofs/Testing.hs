{-# OPTIONS_GHC -itarget #-}
{-# LANGUAGE StandaloneDeriving #-}
module Testing where

import FourPoints
import Basic
import Terms
import qualified LBracketSyntax as LB
import qualified LBracketBigStep as LB
import qualified LBracketSmallStep as LB
import qualified LThrowBigStep as LT
import qualified LThrowSmallStep as LT
import qualified LNaVSyntax as LN
import qualified LNaVSmallStep as LN
import qualified LThrowDBigStep as LD
import qualified LThrowDSmallStep as LD
import qualified EncodeLNaVintoLThrow as EN2T
import qualified EncodeLThrowIntoLNaV as ET2N
import qualified EncodeLThrowIntoLNaVTakeTwo as ET2Np
import qualified EncodeLNaVintoLBracket as EN2B
import qualified EncodeLThrowDIntoLThrow as ED2T
import qualified EncodeLThrowIntoLThrowD as ET2D

import Prelude
-- More info about QuickCheck here:
-- http://www.cse.chalmers.se/~rjmh/QuickCheck/
-- http://book.realworldhaskell.org/read/testing-and-quality-assurance.html
import Test.QuickCheck
-- More info about HUnit here:
-- http://hunit.sourceforge.net/HUnit-1.0/Guide.html
-- http://leiffrenzel.de/papers/getting-started-with-hunit.html
import Test.HUnit
import Data.List as List
import Data.Maybe (fromMaybe)
import Debug.Trace
import Control.Monad (liftM)
import Control.Arrow (second)

deriving instance Show FP
deriving instance Show Tag
deriving instance Show Const
deriving instance Show BOp
deriving instance Show Dir
deriving instance Show Tm
deriving instance Show LN.Box
deriving instance Show LN.Val
deriving instance Show LB.Val
deriving instance Show LT.Result
deriving instance Show LT.Frame
deriving instance Show LD.Result
deriving instance Show LD.Frame

deriving instance Eq FP
deriving instance Eq Tag
deriving instance Eq Const
deriving instance Eq BOp
deriving instance Eq Dir
deriving instance Eq LN.Box
deriving instance Eq LT.Result
deriving instance Eq LD.Result

-- Equality up to alpha

eqVarM :: [(Var, Var)] -> Var -> Var -> Bool
eqVarM m x1 x2 =
  case get m x1 of
    Just x2' -> x2 == x2'
    Nothing -> x1 == x2

eqTmM :: [(Var, Var)] -> Tm -> Tm -> Bool
eqTmM m t1 t2 =
  case (t1, t2) of
    (TVar x1, TVar x2) ->
      eqVarM m x1 x2
    (TConst c1, TConst c2) ->
      c1 == c2
    (TLet x1 t1' t1'', TLet x2 t2' t2'') ->
      eqTmM m t1' t2' && eqTmM ((x1,x2):m) t1'' t2''
    (TAbs x1 t1', TAbs x2 t2') ->
      eqTmM ((x1,x2):m) t1' t2'
    (TApp x1 x1', TApp x2 x2') -> 
      eqVarM m x1 x2 && eqVarM m x1' x2'
    (TInx d1 x1, TInx d2 x2) ->
      d1 == d2 && eqVarM m x1 x2
    (TMatch x1 x1' t1' t1'', TMatch x2 x2' t2' t2'') ->
      eqVarM m x1 x2 && eqTmM ((x1',x2'):m) t1' t2'
                       && eqTmM ((x1',x2'):m) t1'' t2''
    (TTag x1, TTag x2) ->
      eqVarM m x1 x2
    (TBOp bo1 x1 x1', TBOp bo2 x2 x2') ->
      bo1 == bo2 && eqVarM m x1 x2 && eqVarM m x1' x2'
    (TBracket x1 t1', TBracket x2 t2') -> 
      eqVarM m x1 x2 && eqTmM m t1' t2'
    (TLabelOf x1, TLabelOf x2) ->
      eqVarM m x1 x2;
    (TGetPc, TGetPc) -> True
    (TMkNav x1, TMkNav x2) ->
      eqVarM m x1 x2
    (TToSum x1, TToSum x2) ->
      eqVarM m x1 x2;
    (TThrow x1, TThrow x2) ->
      eqVarM m x1 x2;
    (TCatch t1' x1 t1'', TCatch t2' x2 t2'') ->
      eqTmM m t1' t2' && eqTmM ((x1,x2):m) t1'' t2''
    (_, _) -> False

instance Eq Tm where
  (==) = eqTmM []

eqVarLNmr :: [(Var, Var)] -> LN.Env -> LN.Env -> Var -> Var -> Bool
eqVarLNmr m r1 r2 x1 x2 =
   case get m x1 of
     Just x2' -> x2 == x2'
     Nothing ->
       case (get r1 x1, get r2 x2) of
         (Just a1, Just a2) -> eqAtomLNmr [] a1 a2
         (_, _) -> False

eqTmLNmr :: [(Var, Var)] -> LN.Env -> LN.Env -> Tm -> Tm -> Bool
eqTmLNmr m r1 r2 t1 t2 =
  case (t1, t2) of
    (TVar x1, TVar x2) ->
      eqVarLNmr m r1 r2 x1 x2
    (TConst c1, TConst c2) ->
      c1 == c2
    (TLet x1 t1' t1'', TLet x2 t2' t2'') ->
      eqTmLNmr m r1 r2 t1' t2' && eqTmLNmr ((x1,x2):m) r1 r2 t1'' t2''
    (TAbs x1 t1', TAbs x2 t2') ->
      eqTmLNmr ((x1,x2):m) r1 r2 t1' t2'
    (TApp x1 x1', TApp x2 x2') -> 
      eqVarLNmr m r1 r2 x1 x2 && eqVarLNmr m r1 r2 x1' x2'
    (TInx d1 x1, TInx d2 x2) ->
      d1 == d2 && eqVarLNmr m r1 r2 x1 x2
    (TMatch x1 x1' t1' t1'', TMatch x2 x2' t2' t2'') ->
      eqVarLNmr m r1 r2 x1 x2 && eqTmLNmr ((x1',x2'):m) r1 r2 t1' t2'
                              && eqTmLNmr ((x1',x2'):m) r1 r2 t1'' t2''
    (TTag x1, TTag x2) ->
      eqVarLNmr m r1 r2 x1 x2
    (TBOp bo1 x1 x1', TBOp bo2 x2 x2') ->
      bo1 == bo2 && eqVarLNmr m r1 r2 x1 x2 && eqVarLNmr m r1 r2 x1' x2'
    (TBracket x1 t1', TBracket x2 t2') -> 
      eqVarLNmr m r1 r2 x1 x2 && eqTmLNmr m r1 r2 t1' t2'
    (TLabelOf x1, TLabelOf x2) ->
      eqVarLNmr m r1 r2 x1 x2;
    (TGetPc, TGetPc) -> True
    (TMkNav x1, TMkNav x2) ->
      eqVarLNmr m r1 r2 x1 x2
    (TToSum x1, TToSum x2) ->
      eqVarLNmr m r1 r2 x1 x2;
    (TThrow x1, TThrow x2) ->
      eqVarLNmr m r1 r2 x1 x2;
    (TCatch t1' x1 t1'', TCatch t2' x2 t2'') ->
      eqTmLNmr m r1 r2 t1' t2' && eqTmLNmr ((x1,x2):m) r1 r2 t1'' t2''
    (_, _) -> False

eqBoxLNmr :: [(Var, Var)] -> LN.Box -> LN.Box -> Bool
eqBoxLNmr m b1 b2 =
  case (b1, b2) of
    (LN.V v1, LN.V v2) -> eqValLNmr [] v1 v2
    (LN.D e1, LN.D e2) -> e1 == e2
    (_, _) -> False

eqAtomLNmr :: [(Var, Var)] -> LN.Atom -> LN.Atom -> Bool
eqAtomLNmr m a1 a2 =
  eqBoxLNmr m (fst a1) (fst a2) && snd a1 == snd a2
  
eqValLNmr :: [(Var, Var)] -> LN.Val -> LN.Val -> Bool
eqValLNmr m v1 v2 =
  case (v1, v2) of
  (LN.VConst c1, LN.VConst c2) ->
    c1 == c2
  (LN.VInx d1 a1, LN.VInx d2 a2) ->
    d1 == d2 && eqAtomLNmr m a1 a2
  (LN.VClos r1' x1 t1, LN.VClos r2' x2 t2) ->
    eqTmLNmr ((x1, x2):m) r1' r2' t1 t2
  (_, _) -> False

instance Eq LN.Val where
  (==) = eqValLNmr []

-- boring repetition

eqVarLBmr :: [(Var, Var)] -> LB.Env -> LB.Env -> Var -> Var -> Bool
eqVarLBmr m r1 r2 x1 x2 =
   case get m x1 of
     Just x2' -> x2 == x2'
     Nothing ->
       case (get r1 x1, get r2 x2) of
         (Just a1, Just a2) -> eqAtomLBmr [] r1 r2 a1 a2
         (_, _) -> False

eqTmLBmr :: [(Var, Var)] -> LB.Env -> LB.Env -> Tm -> Tm -> Bool
eqTmLBmr m r1 r2 t1 t2 =
  case (t1, t2) of
    (TVar x1, TVar x2) ->
      eqVarLBmr m r1 r2 x1 x2
    (TConst c1, TConst c2) ->
      c1 == c2
    (TLet x1 t1' t1'', TLet x2 t2' t2'') ->
      eqTmLBmr m r1 r2 t1' t2' && eqTmLBmr ((x1,x2):m) r1 r2 t1'' t2''
    (TAbs x1 t1', TAbs x2 t2') ->
      eqTmLBmr ((x1,x2):m) r1 r2 t1' t2'
    (TApp x1 x1', TApp x2 x2') -> 
      eqVarLBmr m r1 r2 x1 x2 && eqVarLBmr m r1 r2 x1' x2'
    (TInx d1 x1, TInx d2 x2) ->
      d1 == d2 && eqVarLBmr m r1 r2 x1 x2
    (TMatch x1 x1' t1' t1'', TMatch x2 x2' t2' t2'') ->
      eqVarLBmr m r1 r2 x1 x2 && eqTmLBmr ((x1',x2'):m) r1 r2 t1' t2'
                              && eqTmLBmr ((x1',x2'):m) r1 r2 t1'' t2''
    (TTag x1, TTag x2) ->
      eqVarLBmr m r1 r2 x1 x2
    (TBOp bo1 x1 x1', TBOp bo2 x2 x2') ->
      bo1 == bo2 && eqVarLBmr m r1 r2 x1 x2 && eqVarLBmr m r1 r2 x1' x2'
    (TBracket x1 t1', TBracket x2 t2') -> 
      eqVarLBmr m r1 r2 x1 x2 && eqTmLBmr m r1 r2 t1' t2'
    (TLabelOf x1, TLabelOf x2) ->
      eqVarLBmr m r1 r2 x1 x2;
    (TGetPc, TGetPc) -> True
    (TMkNav x1, TMkNav x2) ->
      eqVarLBmr m r1 r2 x1 x2
    (TToSum x1, TToSum x2) ->
      eqVarLBmr m r1 r2 x1 x2;
    (TThrow x1, TThrow x2) ->
      eqVarLBmr m r1 r2 x1 x2;
    (TCatch t1' x1 t1'', TCatch t2' x2 t2'') ->
      eqTmLBmr m r1 r2 t1' t2' && eqTmLBmr ((x1,x2):m) r1 r2 t1'' t2''
    (_, _) -> False

eqAtomLBmr :: [(Var, Var)] -> LB.Env -> LB.Env -> LB.Atom -> LB.Atom -> Bool
eqAtomLBmr m r1 r2 a1 a2 =
  eqValLBmr m r1 r2 (fst a1) (fst a2) && snd a1 == snd a2

eqValLBmr :: [(Var, Var)] -> LB.Env -> LB.Env -> LB.Val -> LB.Val -> Bool
eqValLBmr m r1 r2 v1 v2 =
  case (v1, v2) of
  (LB.VConst c1, LB.VConst c2) ->
    c1 == c2
  (LB.VInx d1 a1, LB.VInx d2 a2) ->
    d1 == d2 && eqAtomLBmr m r1 r2 a1 a2
  (LB.VClos r1 x1 t1, LB.VClos r2 x2 t2) ->
    eqTmLBmr ((x1, x2):m) r1 r2 t1 t2
  (_, _) -> False

instance Eq LB.Val where
  (==) = eqValLBmr [] [] []


-- Unit testing the step function for LNaV

-- Redefining nstep/mstep/tstep without the index
-- that was giving us termination guarantees in Coq

nstep' :: LN.Cfg -> LN.Cfg
nstep' c = if LN.final c then c else nstep' (LN.step c)

mstep' :: Tm -> LN.Cfg
mstep' t = nstep' (((Low, []), []), LN.CR t)

tstep' :: Tm -> LN.Atom
tstep' t = 
  case mstep' t of
  (((pc, rho), []), LN.CA a) -> a

testEqTmM1 = TestCase $ assertEqual "eqTmM1"
                  (TAbs 0 (TVar 0))
                  (TAbs 42 (TVar 42))

testEqTmM2 = TestCase $ assertBool "eqTmM2" $
                  TAbs 0 (TVar 0) /= TAbs 0 (TVar 42)

testEqValMr1 = TestCase $ assertEqual "eq_val_mr1"
                    (LN.VClos [] 0 (TVar 0))
                    (LN.VClos [] 2 (TVar 2))

testEqValMr2 = TestCase $ assertEqual "eq_val_mr2"
                    (LN.VClos [] 0 (TVar 0))
                    (LN.VClos [(1,(LN.V LN.vUnit,Low))] 2 (TVar 2))

testEqValMr3 = TestCase $ assertBool "eq_val_mr3" $
                    LN.VClos [] 0 (TVar 1) /=
                    LN.VClos [(1,(LN.V LN.vUnit,Low))] 2 (TVar 2)

testEx0 = TestCase $ assertEqual "step unit"
             (LN.V LN.vUnit, Low)
             (tstep' tCUnit) 

testEx0' = TestCase $ assertEqual "step true"
              (LN.V LN.vTrue, Low)
              (tstep' tTrue)

vId = LN.VClos [] 0 (TVar 0)

testEx1 = TestCase $ assertEqual "step (id id)"
             (LN.V vId, Low)
             (tstep' (tApp tId tId))

prog2 = tIf tTrue tTrue tFalse

testEx2 = TestCase $ assertEqual "step prog2"
             (LN.V LN.vTrue, Low)
             (tstep' prog2)

prog3 = tIf tTrue (TConst (CExcp eType)) (TConst (CExcp eBracket))
res3 =  (LN.V (LN.VConst (CExcp eType)), Low)

testEx3 = TestCase $ assertEqual "step prog3 = res3"
             res3 (tstep' prog3)

-- Properties of FP label algebra
-- These properties are easy to prove in Coq
-- I'm QuickChecking them only to get familiar with QuickCheck


instance Arbitrary FP where
  arbitrary = elements [Low, Med1, Med2, High]

(<:) = fp_flows
(\/) = fp_join

prop_flows_top l = l <: High

prop_flows_bottom l = Low <: l

prop_flows_trans l1 l2 l3 =
  l1 <: l2 ==> l2 <: l3 ==> l1 <: l3

prop_join_commutes l1 l2 = l1 \/ l2 == l2 \/ l1

prop_join_Low l = l \/ Low == l

prop_join_High l = l \/ High == High

prop_join_upper_bound l1 l2 = (l1 <: (l1 \/ l2)) && (l2 <: (l1 \/ l2))

prop_join_minimal l1 l2 l =
  l1 <: l ==> l2 <: l ==> l1 \/ l2 <: l


-- Generating random programs

instance Arbitrary Tag where
  arbitrary = elements [TagFun, TagLab, TagTag, TagExcp]

arbitraryExcp = elements [eType, eBracket, 42]

instance Arbitrary Const where
  arbitrary = oneof $ [liftM CLab arbitrary] ++
                      [liftM CTag arbitrary] ++
                      [liftM CExcp arbitraryExcp]

instance Arbitrary BOp where
  arbitrary = elements [BEq, BCmp, BJoin]
    
arbitraryLBracketTm' :: ([Var] -> Int -> Gen Tm) -> [Var] -> Int -> Gen Tm
arbitraryLBracketTm' frec vars size = 
  frequency $
       [(size `div` 3, do
            s <- choose (0,size-1)
            let x = fresh vars
            t1 <- frec vars s
            t2 <- frec (x:vars) (size-s-1)
            return $ TLet x t1 t2)
       | size > 0]
    ++
    [(1, oneof $
        [liftM TVar (elements vars) | length vars > 0]
        ++
        [liftM TConst arbitrary]
        ++
        [do
            let x = fresh vars
            t <- frec (x:vars) (size-1)
            return $ TAbs x t
        | size>0]
        ++
        [do 
            x1 <- elements vars 
            x2 <- elements vars
            return $ TApp x1 x2
        | length vars > 0]
        ++
        [do 
            x <- elements vars
            let x1 = fresh vars
            s <- choose (0,size-1)
            t1 <- frec vars s
            t2 <- frec (x:vars) (size-s-1)
            return $ TMatch x x1 t1 t2
        | length vars > 0]
        ++
        [liftM TTag (elements vars) | length vars > 0]
        ++
        [do 
            b <- arbitrary
            x1 <- elements vars 
            x2 <- elements vars
            return $ TBOp b x1 x2
        | length vars > 0]
        ++
        [do
            x <- elements vars 
            t <- frec (x:vars) (size-1)
            return $ TBracket x t
        | length vars > 0 && size > 0]
        ++
        [liftM TLabelOf (elements vars) | length vars > 0]
        ++
        [return TGetPc]
    )]

-- tying the recursive knot
arbitraryLBracketTm'' = arbitraryLBracketTm' arbitraryLBracketTm''
arbitraryLBracketTm = sized $ arbitraryLBracketTm'' []

arbitraryLNaVTm' :: [Var] -> Int -> Gen Tm
arbitraryLNaVTm' vars size = 
    frequency $
    (if length vars > 0 then
       [(1, do
            x <- elements vars 
            return $ TMkNav x)]
       ++
       [(1, do
            x <- elements vars 
            return $ TToSum x)]
     else [])
    ++
    [(10, arbitraryLBracketTm' arbitraryLNaVTm' vars size)]

arbitraryLNaVTm = sized $ arbitraryLNaVTm' []

arbitraryLThrowTm' :: [Var] -> Int -> Gen Tm
arbitraryLThrowTm' vars size = 
    frequency $
       [(1, do
            x <- elements vars 
            return $ TThrow x)
       | length vars > 0]
    ++
       [(1 + size `div` 5, do
            s <- choose (0,size-1)
            let x = fresh vars
            t1 <- arbitraryLThrowTm' vars s
            t2 <- arbitraryLThrowTm' (x:vars) (size-s-1)
            return $ TCatch t1 x t2)
       | size>0]
    ++
    [(10, arbitraryLBracketTm' arbitraryLThrowTm' vars size)]

arbitraryLThrowTm = sized $ arbitraryLThrowTm' []

arbitraryLThrowDTm' :: [Var] -> Int -> Gen Tm
arbitraryLThrowDTm' vars size = 
    frequency $
       [(1, do
            x <- elements vars 
            return $ TThrow x)
       | length vars > 0]
    ++
       [(1 + size `div` 5, do
            s <- choose (0,size-1)
            let x = fresh vars
            t1 <- arbitraryLThrowDTm' vars s
            t2 <- arbitraryLThrowDTm' (x:vars) (size-s-1)
            return $ TCatch t1 x t2)
       | size>0]
    ++
       [(1, do
            x <- elements vars 
            return $ TToSum x)
       | length vars > 0]
    ++
      [(10, arbitraryLBracketTm' arbitraryLThrowDTm' vars size)]

arbitraryLThrowDTm = sized $ arbitraryLThrowDTm' []

-- testing that the generators above stay in the corresponding
-- sublanguages

inLThrow :: Tm -> Bool
inLThrow (TMkNav _) = False
inLThrow (TToSum _) = False
inLThrow (TLet _ t1 t2) = inLThrow t1 && inLThrow t2
inLThrow (TAbs _ t) = inLThrow t
inLThrow (TMatch _ _ t1 t2) = inLThrow t1 && inLThrow t2
inLThrow (TBracket _ t) = inLThrow t
inLThrow (TCatch t1 _ t2) = inLThrow t1 && inLThrow t2
inLThrow _ = True

inLThrowD :: Tm -> Bool
inLThrowD (TMkNav _) = False
inLThrowD (TLet _ t1 t2) = inLThrowD t1 && inLThrowD t2
inLThrowD (TAbs _ t) = inLThrowD t
inLThrowD (TMatch _ _ t1 t2) = inLThrowD t1 && inLThrowD t2
inLThrowD (TBracket _ t) = inLThrowD t
inLThrowD (TCatch t1 _ t2) = inLThrowD t1 && inLThrowD t2
inLThrowD _ = True

inLNaV :: Tm -> Bool
inLNaV (TThrow _) = False
inLNaV (TCatch _ _ _) = False
inLNaV (TLet _ t1 t2) = inLNaV t1 && inLNaV t2
inLNaV (TAbs _ t) = inLNaV t
inLNaV (TMatch _ _ t1 t2) = inLNaV t1 && inLNaV t2
inLNaV (TBracket _ t) = inLNaV t
inLNaV _ = True

inLBracket :: Tm -> Bool
inLBracket t = inLNaV t && inLThrow t

prop_arbitraryLBracketTm_inLBracket =
  forAll arbitraryLBracketTm $ \t -> inLBracket t

prop_arbitraryLNaVTm_inLNaV =
  forAll arbitraryLNaVTm $ \t -> inLNaV t

prop_arbitraryLThrowTm_inLThrow =
  forAll arbitraryLThrowTm $ \t -> inLThrow t

prop_arbitraryLThrowDTm_inLThrowD =
  forAll arbitraryLThrowDTm $ \t -> inLThrowD t

-- this seems useful for "collect"-ing statistics
tmKind :: Tm -> String
tmKind (TVar _) = "var"
tmKind (TConst _) = "const"
tmKind (TLet _ _ _) = "let"
tmKind (TAbs _ _) = "abs"
tmKind (TApp _ _) = "app"
tmKind (TTag _) = "tag"
tmKind (TBOp _ _ _) = "bop"
tmKind (TBracket _ _) = "bracket"
tmKind (TLabelOf _) = "label_of"
tmKind (TGetPc) = "get_pc"
tmKind (TMkNav _) = "mk_nav"
tmKind (TToSum _) = "to_sum"
tmKind (TThrow _) = "throw"
tmKind (TCatch _ _ _) = "catch"

-- test that all generated programs are closed

prop_generate_closed_LBracket t =
  forAll arbitraryLBracketTm $ \t -> collect (tmKind t) $ null (fv_tm t)

prop_generate_closed_LNaV t =
  forAll arbitraryLNaVTm $ \t -> collect (size_tm t) $ null (fv_tm t)

prop_generate_closed_LThrow t =
  forAll arbitraryLThrowTm $ \t -> collect (size_tm t) $ null (fv_tm t)

prop_generate_closed_LThrowD t =
  forAll arbitraryLThrowDTm $ \t -> collect (size_tm t) $ null (fv_tm t)

-- equality on terms is an equivalence relation

prop_eq_tm_refl t = t == t

-- the next two properties have very bad coverage,
-- but only when adding collect?
prop_eq_tm_sym t1 t2 =
  -- collect (t1 == t2, tmKind t1, size_tm t1) $
  (t1 == t2) ==> (t2 == t1)

prop_eq_tm_trans t1 t2 t3 =
  (t1 == t2 && t2 == t3) ==> (t1 == t3)

-- the small-step semantics of LambdaNaV never produces "bad" exceptions

badExcp :: Excp -> Bool
badExcp e = e >= 2 && e < 42

atomBadExcp :: LN.Atom -> Bool
atomBadExcp (LN.D e, _) = badExcp e
atomBadExcp _ = False

mAtomBadExcp :: Maybe ((LN.Atom, FP),Integer) -> Bool
mAtomBadExcp (Just ((a,_pc),_)) = atomBadExcp a
mAtomBadExcp Nothing = False

boxKind :: LN.Box -> String
boxKind (LN.V (LN.VConst _)) = "constant"
boxKind (LN.V (LN.VInx _ _)) = "sum"
boxKind (LN.V (LN.VClos _ _ _)) = "function"
boxKind (LN.D e) = "NaV"

-- we only run for sn steps to get rid of out of memory errors
sn = 1000

stepInteval :: Integer -> String
stepInteval n =
  let middle = div sn 2 in
  if n < middle then "[0," ++ show middle ++ ")"
  else "[" ++ show middle ++ "," ++ show sn ++ "]"

finishedLN :: Maybe ((LN.Atom,FP),Integer) -> String
finishedLN (Just (((b, _pc), _), n)) =
  "Finished with " ++ boxKind b ++ " after " ++ stepInteval n ++ " steps"
finishedLN Nothing = "Not finished after " ++ show sn ++ " steps"

prop_ln_no_badExcp t =
  forAll arbitraryLNaVTm $ \t -> 
  let mapcs = LN.sstep sn t in
      collect (finishedLN mapcs) $
        not $ mAtomBadExcp mapcs

-- the small-step semantics of LambdaThrow never produces "bad" exceptions

resultBadExcp :: LT.Result -> Bool
resultBadExcp (LT.Throw e) = badExcp e
resultBadExcp _ = False

mResBadExcp :: Maybe ((LT.Result,FP),Integer) -> Bool
mResBadExcp (Just ((r,_pc),_step)) = resultBadExcp r
mResBadExcp Nothing = False

resKind :: LT.Result -> String
resKind (LT.Suc (LB.VConst _, _)) = "constant"
resKind (LT.Suc (LB.VInx _ _, _)) = "sum"
resKind (LT.Suc (LB.VClos _ _ _, _)) = "function"
resKind (LT.Throw e) = "exception"

finishedLT :: Maybe ((LT.Result,FP),Integer) -> String
finishedLT (Just ((res,_pc), n)) =
  "Finished with " ++ resKind res ++ " after " ++ stepInteval n ++ " steps"
finishedLT Nothing = "Not finished after " ++ show sn ++ " steps"

prop_lt_no_badExcp t = 
  forAll arbitraryLThrowTm $ \t -> 
  let mrs = LT.sstep sn t in
      collect (finishedLT mrs) $
        not $ mResBadExcp mrs

-- the small-step semantics of LambdaThrowD never produces "bad" exceptions

resultBadExcpLD :: LD.Result -> Bool
resultBadExcpLD (LD.Throw e) = badExcp e
resultBadExcpLD _ = False

mResBadExcpLD :: Maybe ((LD.Result,FP),Integer) -> Bool
mResBadExcpLD (Just ((r,_pc),_step)) = resultBadExcpLD r
mResBadExcpLD Nothing = False

resKindLD :: LD.Result -> String
resKindLD (LD.Suc (LN.V (LN.VConst _), _)) = "constant"
resKindLD (LD.Suc (LN.V (LN.VInx _ _), _)) = "sum"
resKindLD (LD.Suc (LN.V (LN.VClos _ _ _), _)) = "function"
resKindLD (LD.Suc (LN.D _, _)) = "delayed-excp"
resKindLD (LD.Throw e) = "exception"

finishedLD :: Maybe ((LD.Result,FP),Integer) -> String
finishedLD (Just ((res,_pc), n)) =
  "Finished with " ++ resKindLD res ++ " after " ++ stepInteval n ++ " steps"
finishedLD Nothing = "Not finished after " ++ show sn ++ " steps"

prop_ltd_no_badExcp t = 
  forAll arbitraryLThrowDTm $ \t -> 
  let mrs = LD.sstep sn t in
      collect (finishedLD mrs) $
        not $ mResBadExcpLD mrs

-- testing the translation from LNaV into LThrow

-- encoded program in LThrow always produces a sum result (or loops forever)
-- in particular, encoded program causes no fatal errors (uncaught exceptions)

prop_EN2T_sum =
  forAll arbitraryLNaVTm $ \t ->
  let mrs = LT.sstep sn (EN2T.encode t) in
  collect (finishedLT mrs) $
  case mrs of
    Just ((LT.Suc (LB.VInx _ _, _), _), _) -> True
    Just _ -> False
    Nothing -> True

-- some helpers that are useful for debugging

minimizeEnv :: [Var] -> LB.Env -> LB.Env
minimizeEnv vars rho = Prelude.map (\x -> (x, fromMaybe (LB.vUnit, Low) (get rho x))) vars

showCfg :: LT.Cfg -> String
showCfg (((_pc, rho), _k), LT.CR t) =
  "\n\nCR ( " ++ show t ++ 
--  "\nwhere rho (minimized) = "++ show (minimizeEnv (nub (fv_tm t)) rho) ++ " )"
  "\nwhere rho = "++ show rho ++ " )"
showCfg (((_pc, rho), k), LT.CA a) =
  "\n\nCA with "
  ++ (if null k then "empty k" else "head k=" ++ show (head k))
  ++ "\nwhere a = " ++ show a
  ++ "\nand with rho = " ++ show rho
showCfg (_, LT.CT e) = "\n\nCT" ++ show e

-- debugging stuff 
encN2T_no_excp_instance = 
  let t = TLet 1001 (TLet 1001 (TConst (CLab Med1)) (TToSum 1001)) (TLet 1002 (TLet 1002 (TLet 1002 (TLet 1002 (TVar 1001) (TTag 1002)) (TApp 1001 1001)) (TLet 1003 (TLet 1003 (TApp 1001 1002) (TLet 1004 (TAbs 1004 (TTag 1001)) TGetPc)) (TApp 1002 1001))) (TToSum 1001)) in
  let t' = EN2T.encode t in
  let tr = List.reverse $ snd $ LT.lmstep sn t' in
  let tr' = Prelude.map showCfg tr in
  (t', drop (length tr' - 10) tr', length tr') -- drop (length tr' - 10) tr'

-- mapping function between LambdaNaV values and LThrow values
-- note: it has to go in this direction
-- (the other direction is not functional / deterministic)

valEN2T :: LN.Val -> LB.Val
valEN2T (LN.VConst c) = LB.vInl (LB.VConst c, Low)
valEN2T (LN.VInx d aLN) = LB.vInl (LB.VInx d $ atomEN2T aLN, Low)
valEN2T (LN.VClos rho x t) =
  let rho' = List.map (second atomEN2T) rho in
  let t' = EN2T.encode t in
  LB.vInl (LB.VClos rho' x t' , Low)

atomEN2T :: LN.Atom -> LB.Atom
atomEN2T (LN.V v,l) = (valEN2T v, l)
atomEN2T (LN.D e,l) = (LB.vInr (LB.vExcp e, Low), l)

prop_EN2T_correct =
  forAll arbitraryLNaVTm $ \tLN ->
  let tLT = EN2T.encode tLN in
  let mrs = LT.sstep sn tLT in
  collect (finishedLT mrs) $
  case mrs of
    Just ((LT.Throw e, _pc), _) -> False -- checked by prop_EN2T_no_excp
    Just ((LT.Suc aLT, pcLT), _) -> 
      case LN.sstep sn tLN of
        Just ((aLN, pcLN),_) ->
          pcLT == pcLN && atomEN2T aLN == aLT
        Nothing -> True -- this won't happen anyway
    Nothing -> True

test_EN2T_instance =
  let t = TLet 1 TGetPc (TLet 2 (TCatch (TMatch 1 2 (TBOp BJoin 1 1) (TConst (CTag TagExcp))) 2 (TLabelOf 1)) (TLet 3 (TTag 2) TGetPc)) in
  let t' = EN2T.encode t in
  let Just ((LT.Suc a', pcLT),_s) = LT.sstep sn t' in
  let Just ((a, pcLN),_s) = LN.sstep sn t in
  TestCase $ assertBool "test_encLNintoLT_instance" $
  atomEN2T a == a'

vBox :: LN.Atom -> LN.Val
vBox = LN.vInl

resET2N :: LT.Result -> LN.Atom
resET2N (LT.Throw e) = (LN.D e, Low)
resET2N (LT.Suc a) = (LN.V (vBox (atomET2N a)), Low)

valET2N :: LB.Val -> LN.Val
valET2N (LB.VConst c) = LN.VConst c
valET2N (LB.VInx d a) = LN.VInx d (atomET2N a)
valET2N (LB.VClos rho x t) =
  let rho' = List.map (second atomET2N) rho in
  let t' = ET2N.encode t in
  (LN.VClos rho' x t')

atomET2N :: LB.Atom -> LN.Atom
atomET2N (v,l) = (LN.V (valET2N v), l)

prop_ET2N_correct =
  forAll arbitraryLThrowTm $ \t ->
  let t' = ET2N.encode t in
  let mas = LN.sstep sn t' in
  collect (finishedLN mas) $
  case mas of
    Just ((aLN,pcLN),_) ->
      case LT.sstep sn t of
        Just ((resLT, pcLT), _) -> 
          resET2N resLT == aLN
        Nothing -> True -- this won't happen anyway
    Nothing -> True


-- encoded program in LThrow always produces a sum result (or loops
-- forever) in particular, encoded program causes no NaVs

prop_ET2Np_sum =
  forAll arbitraryLThrowTm $ \t ->
  let mas = LN.sstep sn (ET2Np.encode t) in
  collect (finishedLN mas) $
  case mas of
    Just (((LN.V (LN.VInx _ _), _), _), _) -> True
    Just _ -> False
    Nothing -> True

resET2Np :: LT.Result -> LN.Atom
resET2Np (LT.Suc a) = (LN.V (LN.vInl (atomET2Np a)), Low)
resET2Np (LT.Throw e) = (LN.V (LN.vInr (LN.V (LN.VConst (CExcp e)), Low)), Low)

valET2Np :: LB.Val -> LN.Val
valET2Np (LB.VConst c) = LN.VConst c
valET2Np (LB.VInx d a) = LN.VInx d (atomET2Np a)
valET2Np (LB.VClos rho x t) =
  let rho' = List.map (second atomET2Np) rho in
  let t' = ET2Np.encode t in
  (LN.VClos rho' x t')

atomET2Np :: LB.Atom -> LN.Atom
atomET2Np (v,l) = (LN.V (valET2Np v), l)

prop_ET2Np_correct =
  forAll arbitraryLThrowTm $ \t ->
  let t' = ET2Np.encode t in
  let mas = LN.sstep sn t' in
  collect (finishedLN mas) $
  case mas of
    Just ((aLN,pcLN),_) ->
      case LT.sstep sn t of
        Just ((resLT, pcLT), _) -> 
          resET2Np resLT == aLN
        Nothing -> True -- this won't happen anyway
    Nothing -> True

some_ET2Np_instance =
  let t = TLet 1 (TLet 1 (TConst (CLab High)) (TLet 2 (TCatch (TLet 2 (TMatch 1 2 (TApp 1 1) (TConst (CLab High))) (TApp 1 2)) 2 (TBracket 1 (TBOp BCmp 2 2))) (TTag 2))) (TBOp BEq 1 1) in
  let t' = ET2Np.encode t in
  let Just ((aLN, pcLN), _s) = LN.sstep sn t' in
  let Just ((resLT, pcLT), _s) = LT.sstep sn t in
  putStr $
  "t'=" ++ show  t' ++ 
  "\naLN (got after translation) = " ++ show aLN ++ 
  "\nresLT = " ++ show resLT ++
  "\nresET2N resLT (expected) = " ++ show (resET2Np resLT) ++
  "\ncorrect = " ++ show (resET2Np resLT == aLN) ++ "\n"


-- Programs encoded by EN2L always produce a double sum result (or
-- loop forever); in particular, encoded programs do not fatally fail

valKindLB :: LB.Val -> String
valKindLB (LB.VConst _) = "constant"
valKindLB (LB.VInx _ _) = "sum"
valKindLB (LB.VClos _ _ _) = "function"

finishedLB :: Maybe (Maybe (LB.Atom, FP), Integer) -> String
finishedLB (Just (Just ((v, _l), _pc), n)) =
  "Finished with " ++ valKindLB v ++ " after " ++ stepInteval n ++ " steps"
finishedLB (Just (Nothing, n)) =
  "Fatal error after " ++ stepInteval n ++ " steps"
finishedLB Nothing = "Not finished after " ++ show sn ++ " steps"

prop_EN2B_double_sum =
  forAll arbitraryLNaVTm prop_EN2B_double_sum'

prop_EN2B_double_sum' t =
  let mas = LB.sstep sn (EN2B.encode t) in
--  collect (finishedLB mas) $
  case mas of
    Just (Just ((LB.VInx _ (LB.VInx _ _, _l), Low), _pc), _n) -> True
    Just _ -> False
    Nothing -> True

resEN2B :: LN.Atom -> LB.Atom
resEN2B a = (LB.vInl (atomEN2B a), Low)

-- TODO: this will need to be much more complicated because of clearance
valEN2B :: LN.Val -> LB.Val
valEN2B (LN.VConst c) = LB.VConst c
valEN2B (LN.VInx d a) = LB.VInx d (atomEN2B a)
valEN2B (LN.VClos rho x t) =
  let rho'' = List.map (\(x,a) -> (x, atomEN2B a)) rho in
  let rho' = (100, (LB.VConst (CLab High), Low)) : rho'' in
  let t' = EN2B.encode' t 100 in {- TODO: what clearance? -}
  (LB.VClos rho' x t')

boxEN2B :: LN.Box -> LB.Val
boxEN2B (LN.V v) = LB.vInl (valEN2B v, Low)
boxEN2B (LN.D e) = LB.vInr (LB.vExcp e, Low)

atomEN2B :: LN.Atom -> LB.Atom
atomEN2B (b,l) = (boxEN2B b, l)

-- hack: filtering out the results containing closures, since I can't
-- properly compare them in the presence of clearance

hasClos :: LB.Val -> Bool
hasClos (LB.VConst c) = False
hasClos (LB.VInx d a) = hasClosAtom a
hasClos (LB.VClos rho x t) = True
hasClosAtom (v,l) = hasClos v

prop_EN2B_correct =
  forAll arbitraryLNaVTm $ \tLN ->
  let tLB = EN2B.encode tLN in
  let rLB = LB.sstep sn tLB in
  collect (finishedLB rLB) $
  case rLB of
    Just (Just (aLB, pcLB), _) ->
      case LN.sstep sn tLN of
        Just ((aLN, pcLT), _) ->
          not (hasClosAtom aLB) ==> -- discards around 5% of the tests
          pcLB == pcLT && resEN2B aLN == aLB
        Nothing -> property True -- this won't happen anyway
    Just (Nothing, _) -> property False
    Nothing -> property True

test_EN2B_instance =
  let tLN = TLet 1 
              (TConst (CLab High))
              (TLet 2
                (TBracket 1 (TLabelOf 1))
                (TBracket 2 (TMkNav 2))
              )
  in
  let tLB = EN2B.encode tLN in
  let Just (Just (aLB, pcLB), _) = LB.sstep sn tLB in
  let Just ((aLN, pcLT), _) = LN.sstep sn tLN in
  -- putStr $
  -- "tLB=" ++ show  tLB ++ 
  -- "\naLN (original) = " ++ show aLN ++
  -- "\naLB (encoding) = " ++ show aLB ++
  -- "\nresEN2B aLN (expected) = " ++ show (resEN2B aLN) ++
  -- "\ncorrect = " ++ show (pcLB == pcLT && resEN2B aLN == aLB) ++ "\n"
  TestCase $ assertBool "test_EN2B_instance" $
  pcLB == pcLT && resEN2B aLN == aLB


-- testing translation from LThrow into LThrowD

prop_ED2T_sum =
  forAll arbitraryLThrowDTm $ \t ->
  let mrs = LT.sstep sn (ED2T.encode t) in
  collect (finishedLT mrs) $
  case mrs of
    Just ((LT.Suc (LB.VInx _ _, _), _), _) -> True
    Just ((LT.Throw _, _), _) -> True
    Just _ -> False
    Nothing -> True

valED2T :: LN.Val -> LB.Val
valED2T (LN.VConst c) = LB.VConst c
valED2T (LN.VInx d aLD) = LB.VInx d $ atomED2T aLD
valED2T (LN.VClos rho x t) =
  let rho' = List.map (second atomED2T) rho in
  let t' = ED2T.encode t in
  LB.VClos rho' x t'

atomED2T :: LN.Atom -> LB.Atom
atomED2T (LN.V v,l) = (LB.vInl (valED2T v, Low), l)
atomED2T (LN.D e,l) = (LB.vInr (LB.vExcp e, Low), l)

resED2T :: LD.Result -> LT.Result
resED2T (LD.Suc a) = LT.Suc (atomED2T a)
resED2T (LD.Throw e) = LT.Throw e

prop_ED2T_correct =
  forAll arbitraryLThrowDTm $ \tLD ->
  let tLT = ED2T.encode tLD in
  let mrs = LT.sstep sn tLT in
  collect (finishedLT mrs) $
  case mrs of
    Just ((resLT, pcLT), _) ->
      case LD.sstep sn tLD of
        Just ((resLD, pcLD),_) ->
          pcLT == pcLD && resED2T resLD == resLT
        Nothing -> True -- this won't happen anyway
    Nothing -> True

test_ED2T_instance =
   let tLD = TLet 1 (TConst (CLab High)) (TLet 2 (TConst (CExcp 42)) (TLet 3 (TBracket 1 (TVar 2)) (TBOp BCmp 2 3))) in
  let tLT = ED2T.encode tLD in
  let Just ((resLD, pcLD), _) = LD.sstep sn tLD in
  let Just ((resLT, pcLT), _) = LT.sstep sn tLT in
  -- putStr $
  -- "tLT=" ++ show tLT ++ 
  -- "\nresLD (original) = " ++ show resLD ++
  -- "\npcLD (original) = " ++ show pcLD ++
  -- "\nresLT (encoding) = " ++ show resLT ++
  -- "\npcLT (encoding) = " ++ show pcLT ++
  -- "\nresED2T resLD (expected) = " ++ show (resED2T resLD) ++
  -- "\ncorrect = " ++ show (pcLT == pcLD && resED2T resLD == resLT) ++ "\n"
  TestCase $ assertBool "test_ED2T_instance" $
  pcLT == pcLD && resED2T resLD == resLT


-- testing (trivial) translation from LThrow into LThrowD

prop_ET2D_no_primitive_delayed =
  forAll arbitraryLThrowDTm $ \t ->
  let mrs = LD.sstep sn (ET2D.encode t) in
  collect (finishedLD mrs) $
  case mrs of
    Just ((LD.Suc (LN.V _, _), _), _) -> True
    Just ((LD.Throw _, _), _) -> True
    Just _ -> False
    Nothing -> True

-- this is basically just identity/injection

valET2D :: LB.Val -> LN.Val
valET2D (LB.VConst c) = LN.VConst c
valET2D (LB.VInx d aLT) = LN.VInx d $ atomET2D aLT
valET2D (LB.VClos rho x t) =
  let rho' = List.map (\(x,a) -> (x, atomET2D a)) rho in
  let t' = ET2D.encode t in
  LN.VClos rho' x t'

atomET2D :: LB.Atom -> LN.Atom
atomET2D (v,l) = (LN.V (valET2D v), l)

resET2D :: LT.Result -> LD.Result
resET2D (LT.Suc a) = LD.Suc (atomET2D a)
resET2D (LT.Throw e) = LD.Throw e

prop_ET2D_correct =
  forAll arbitraryLThrowTm $ \tLT ->
  let tLD = ET2D.encode tLT in
  let mrs = LD.sstep sn tLD in
  collect (finishedLD mrs) $
  case mrs of
    Just ((resLD, pcLD), _) ->
      case LT.sstep sn tLT of
        Just ((resLT, pcLT),_) ->
          pcLD == pcLT && resET2D resLT == resLD
        Nothing -> True -- this won't happen anyway
    Nothing -> True

test_ET2D_instance =
--  let tLT = TLet 1 (TLet 1 (TConst (CLab Med2)) (TBracket 1 (TLabelOf 1))) (TCatch (TThrow 1) 2 (TCatch (TTag 1) 3 (TLet 4 (TThrow 3) (TCatch (TLet 5 TGetPc (TThrow 1)) 5 (TThrow 3))))) in
  let tLT = TLet 1 (TLet 1 (TLet 1 (TConst (CLab Med2)) (TCatch (TThrow 1) 2 (TBracket 1 (TBOp BCmp 1 1)))) (TVar 1)) (TTag 1) in
  let tLD = ET2D.encode tLT in
  let Just ((resLT, pcLT), _) = LT.sstep sn tLT in
  let Just ((resLD, pcLD), _) = LD.sstep sn tLD in
  -- putStr $
  -- "tLT=" ++ show tLT ++ 
  -- "\nresLT (original) = " ++ show resLT ++
  -- "\npcLT (original) = " ++ show pcLT ++
  -- "\nresLD (encoding) = " ++ show resLD ++
  -- "\npcLD (encoding) = " ++ show pcLD ++
  -- "\nresET2D resLT (expected) = " ++ show (resET2D resLT) ++
  -- "\ncorrect = " ++ show (pcLD == pcLT && resET2D resLT == resLD) ++ "\n"
  TestCase $ assertBool "test_ET2D_instance" $
  pcLD == pcLT && resET2D resLT == resLD


main = runTestTT $ TestList
       [testEqTmM1, testEqTmM2,
        testEqValMr1, testEqValMr2, testEqValMr3,
        testEx0, testEx0', testEx1, testEx2, testEx3
       , test_EN2T_instance
       , test_EN2B_instance
       , test_ED2T_instance
       , test_ET2D_instance
       ]

-- To run 500,000 instances random tests use this:
runP :: Test.QuickCheck.Testable prop => prop -> IO ()
runP = quickCheckWith (stdArgs {maxSuccess = 500000})
-- More Args:
-- replay :: Maybe (StdGen, Int)
--     should we replay a previous test? 
-- maxSuccess :: Int
--     maximum number of successful tests before succeeding 
-- maxDiscard :: Int
--     maximum number of discarded tests before giving up 
-- maxSize :: Int
--     size to use for the biggest test cases 
-- chatty :: Bool
--     whether to print anything 

-- To test the correctness of all encodings use this:
runAll = do
  runP prop_EN2T_correct
  runP prop_ET2N_correct
  runP prop_ET2Np_correct
  runP prop_EN2B_correct
  runP prop_ED2T_correct
  runP prop_ET2D_correct

-- TODO: is an encoding from LT into LB that is similar to the one
-- from LT into LN possible? [Yes, this is possible, but we can also
-- get it by transitivity, by composing ET2N and EN2B]
-- It would have to use a fixed version of
-- the clearance idea, but otherwise why not?
-- Suc (v@l) --> (S (v@l))@bot
-- Throw e --> (T (e@bot))@bot
-- clearance failure -> C@bot
-- for an encoded datatype Data = S v | T e | C
-- (basically encoding "option (inl v)" would do)
-- Note that, as in ET2N, the variables in the environment will only
-- store real values.

-- TODO: how about a special term generator where more
-- classification/brackets is/are used

-- TODO: generate globally unique names
-- (bound list + keep bigger avoid list)

-- TODO: Check that step preserves the same set of free + bound names

-- TODO: check that step _preserves_ fv inluded in dom rho
-- Q: How to show that such _invariants_ are preserved by the semantics
-- the problem is that not all random configurations are "good"
-- starting configurations; so maybe the check needs to be done
-- part of the step iteration function

-- TODO: nstep and lnstep have
-- {- XXX if this appears you might want to optimize things -}

-- TODO: how about building another generator using the "t_..."
-- derived forms (then we don't need to bias generating lets and we
-- can maybe generate more meaningful programs)?

-- TODO: special generator for well-typed programs??
-- at least in LThrow ~70% of the programs terminate with exceptions

-- TODO: implement shrinking; e.g. check this out:
-- http://publications.lib.chalmers.se/records/fulltext/157525.pdf
-- we could use:
-- - subterms (assuming they are well-formed)
-- - reduction (step)
--   -- if we bound the number of steps (otherwise we could loop)
--      (e.g. could require that the size of the term decreases)
--   -- if we can turn "configurations" back into terms
--      (basically turning an environment-based semantics
--       into a substitution-based one)
-- - could keep top level constructor but shrink the subterms
-- (QuickCheck shrinking is a greedy algorithm)

