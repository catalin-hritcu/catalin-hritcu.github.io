Copyright (c) 2010-2011 Catalin Hritcu
Licensed under the Creative Commons - Attribution 3.0 Unported
The license is available at: http://creativecommons.org/licenses/by/3.0/

* Coq version

These proof scripts compile with Coq v8.2 on my machine.
They don't work with Coq v8.3, which is backwards incompatible in many respects.

* Intended model

The intended model used by our logical semantics is defined and proved to
be well-formed in Model.v. This file uses ValueEquality.v, Values.v,
InsertionSorting.v, Scalars.v, and Basic.v. These files total around 2000LOC.

* Properties of the intended model

We have attempted to prove formally that the axioms we feed to the SMT solver
are indeed properties of the intended model. We are not Coq experts and
unfortunately we run into technical difficulties we could not overcome in a
reasonable amount of time when trying to finish these proofs.
The partial proofs are available in file Axioms.v.

The technical difficulties come from the use of sigma types (Sozeau 2006),
which were very appealing for defining a clean model, but turned out to be very
painful to use in the proofs. We use sigma types to obtain a canonical
representation of values, for which equality is purely syntactic. The use of
sigma types means that the huge proof terms showing that values are in normal
form, etc. are weaved into the definition of the functions in our model.
This bites us when trying to prove more complex properties of these functions,
such as the isomorphism between collections and entities represented as
normalized lists  and collections and entities represented as extensional
arrays. In such proofs any unfolding or simplification causes the intermediate
proof terms to grow so large that Coq runs for ages.

* Proofs of Lemmas and Theorems

The following table lists which proofs from our JFP paper were (also) checked in
Coq, and reports on the status of these Coq proofs. 

Lemma 12 - BigStepSemantics.v - Eval_D_entails_Eval
         - checked the only interesting cases, the ones about accumulate
Lemma 13 - BigStepSemantics.v - Pure_Eval_entails_Eval_D - checked the interesting cases
Lemma 14 - BigStepSemantics.v - L30 and L30_D
         - checked all the interesting cases, proof also done in LaTeX
          (important cases like (Eval Accum D) proved both in Coq and in LaTeX)
Lemma 19 - SmallStepSemantics.v - reduction_preserves_A_Pure and
           AlgPure_implies_A_Pure and A_Pure_implies_AlgPure - complete proof
Lemma 22 - BigStepSemantics.v - L30_alg_purity
         - checked only most interesting cases, the ones about accumulate
Lemma 23 - BigStepSemantics.v - alg_pure_result_uniqueness - complete proof (trivial)
Lemma 43 (Canonical Forms) - SmallStepSemantics.v - canonical_form_* - complete proof
Lemma 44 (Progress for Type-tests) - SmallStepSemantics.v - test_val_progress - complete proof
Theorem 5 (Progress) -  SmallStepSemantics.v - progress - checked all cases
         other than the one for entities, where the formalization gets in the way

* Research Papers

Gavin M. Bierman, Andrew D. Gordon, Catalin Hritcu, and David Langworthy.
Semantic Subtyping with an SMT Solver, Journal of Functional Programming,
To appear.

Gavin M. Bierman, Andrew D. Gordon, Catalin Hritcu, and David Langworthy,
Semantic Subtyping with an SMT Solver, no. MSR-TR-2010-99, December 2010.

Gavin M. Bierman, Andrew D. Gordon, Catalin Hritcu, and David Langworthy.
Semantic Subtyping with an SMT Solver, In 15th ACM SIGPLAN International
Conference on Functional Programming (ICFP 2010), September 2010.

* Project website

http://research.microsoft.com/en-us/projects/dminor/

